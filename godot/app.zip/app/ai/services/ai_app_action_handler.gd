extends Node
class_name AIAppActionHandler

const ACTION_CHANGE_SETTINGS := "actions/change_settings/"
const ACTION_SIMULATION := "actions/simulation/"
const ACTION_NAVIGATE := "actions/navigate/"
const ACTION_CREATE := "actions/create/"
const ACTION_GALAXY := "actions/galaxy/"
const JUST_TALK := "just_talk/"

const INPUT_BLOCKER_LAYER := 20000
const INPUT_BLOCKER_EXTRA_HOLD_TIME := 0.28

const AI_ACTION_START_PAUSE := 0.22
const AI_ACTION_END_PAUSE := 0.22
const AI_CREATE_BEFORE_TYPING_PAUSE := 0.38
const AI_CREATE_AFTER_TYPING_PAUSE := 0.42
const AI_CREATE_AFTER_PLUS_PAUSE := 0.34

var assistant: AIAssistant = null
var settings: Node = null

var _input_blocker_layer: CanvasLayer = null
var _input_blocker: Control = null


func setup(owner: AIAssistant) -> void:
	assistant = owner
	settings = get_node_or_null("/root/UnilearnUserSettings")


func handles(folder: String) -> bool:
	folder = folder.strip_edges()

	return (
		folder.begins_with(ACTION_CHANGE_SETTINGS)
		or folder.begins_with(ACTION_NAVIGATE)
		or folder.begins_with(ACTION_CREATE)
		or folder.begins_with(ACTION_SIMULATION)
		or folder.begins_with(ACTION_GALAXY)
		or folder.begins_with(JUST_TALK)
	)


func get_response_override(folder: String, spoken_text: String = "", params: Dictionary = {}) -> Dictionary:
	folder = folder.strip_edges()

	var remove_state := _simulation_remove_body_blocking_state(folder, spoken_text)
	if not remove_state.is_empty():
		params["_apollo_skip_action_execution"] = true
		params["_apollo_action_failed"] = true
		params["_apollo_response_override_folder"] = str(remove_state.get("folder", ""))
		return remove_state

	if _is_action_already_satisfied(folder, params):
		return {
			"folder": _already_response_folder(folder),
			"text": _already_response_text(folder, spoken_text, params)
		}

	return {}


func _simulation_remove_body_blocking_state(folder: String, spoken_text: String = "") -> Dictionary:
	folder = folder.strip_edges()

	if folder != "actions/simulation/remove_body":
		return {}

	var remove_query := _extract_planet_query_from_command(spoken_text)

	if remove_query.is_empty():
		return {
			"folder": "actions/simulation/remove_body_not_found",
			"text": "I could not tell which planet to remove."
		}

	var remove_card: Variant = _find_planet_card_from_query(remove_query, true)

	if remove_card == null:
		return {
			"folder": "actions/already/simulation/remove_body_not_in_scene",
			"text": "That planet is not in the scene right now, so there is nothing to remove."
		}

	if not _is_card_currently_in_scene(remove_card):
		return {
			"folder": "actions/already/simulation/remove_body_not_in_scene",
			"text": "%s is not in the scene right now, so there is nothing to remove." % _card_display_name(remove_card)
		}

	return {}


func _is_action_already_satisfied(folder: String, params: Dictionary = {}) -> bool:
	folder = folder.strip_edges()

	if folder.begins_with(ACTION_CHANGE_SETTINGS):
		return _is_setting_action_already_applied(folder.trim_prefix(ACTION_CHANGE_SETTINGS))

	if folder.begins_with(ACTION_NAVIGATE):
		return _is_navigation_action_already_applied(folder.trim_prefix(ACTION_NAVIGATE), params)

	if folder == "actions/galaxy/set_simulation_parameter":
		return _is_galaxy_parameter_already_applied(params)

	if folder == "actions/galaxy/toggle_setting":
		return _is_galaxy_toggle_already_applied(params)

	return false


func _already_response_folder(folder: String) -> String:
	folder = folder.strip_edges().trim_prefix("actions/")

	if folder.is_empty():
		return "actions/already/generic"

	return "actions/already/" + folder


func _already_response_text(folder: String, _spoken_text: String = "", params: Dictionary = {}) -> String:
	folder = folder.strip_edges()

	if folder.begins_with(ACTION_CHANGE_SETTINGS):
		return "That setting is already the way you asked."

	if folder.begins_with(ACTION_NAVIGATE):
		var category := str(params.get("category", "")).strip_edges()

		if folder == "actions/navigate/enter_achievements" and not category.is_empty():
			return "You're already in that achievement category."

		return "You're already there."

	if folder == "actions/galaxy/set_simulation_parameter":
		return "That slider is already at the requested value."

	if folder == "actions/galaxy/toggle_setting":
		return "That toggle is already set that way."

	return "That is already done."


func execute_before_response(folder: String, _spoken_text: String = "", params: Dictionary = {}) -> void:
	folder = folder.strip_edges()

	if bool(params.get("_apollo_skip_action_execution", false)):
		return

	# Navigation commands can briefly play their voice response before the actual
	# screen transition starts. Keep a global invisible blocker up for that whole
	# AI-driven navigation window so the user cannot tap, drag, scroll, or trigger
	# another popup halfway through Apollo's action.
	if folder.begins_with(ACTION_NAVIGATE):
		_show_navigation_input_blocker()


func prepare_achievement_for_action(folder: String, spoken_text: String = "", params: Dictionary = {}) -> Dictionary:
	folder = folder.strip_edges()
	var output := params.duplicate(true)

	if bool(output.get("_apollo_achievement_tracked", false)):
		return output

	var remove_state := _simulation_remove_body_blocking_state(folder, spoken_text)
	if not remove_state.is_empty():
		output["_apollo_skip_action_execution"] = true
		output["_apollo_action_failed"] = true
		output["_apollo_response_override_folder"] = str(remove_state.get("folder", ""))
		output["_apollo_achievement_tracked"] = true
		return output

	if settings == null:
		settings = get_node_or_null("/root/UnilearnUserSettings")

	var achievement_kind := _ai_achievement_kind_for_folder(folder)
	var should_track_achievement := bool(output.get("_apollo_response_played", true))
	var already_satisfied := _is_action_already_satisfied(folder, output) if should_track_achievement else false

	if should_track_achievement and not achievement_kind.is_empty():
		# Planet creation is only a successful creation after the card cache reports
		# that a new card was actually generated. Track it from _run_create_planet_action.
		if folder != "actions/create/planet":
			var achievement_payload := {"folder": folder, "kind": achievement_kind, "text": spoken_text, "params": output}
			_track_ai_assistant_event("action", achievement_payload)
			_track_ai_assistant_event(achievement_kind, achievement_payload)
			_track_ai_assistant_event("successful_command", achievement_payload)

			if folder == "just_talk/joke":
				_track_ai_assistant_event("joke", achievement_payload)

			if already_satisfied:
				_track_ai_assistant_event("already", achievement_payload)

	output["_apollo_achievement_tracked"] = true
	return output


func execute_on_response_started(folder: String, spoken_text: String = "", params: Dictionary = {}) -> void:
	folder = folder.strip_edges()

	if settings == null:
		settings = get_node_or_null("/root/UnilearnUserSettings")

	if not bool(params.get("_apollo_achievement_tracked", false)):
		params = prepare_achievement_for_action(folder, spoken_text, params)

	if bool(params.get("_apollo_skip_action_execution", false)):
		return

	match folder:
		"actions/change_settings/sfx_on":
			await _apply_setting_action("sfx_on")

		"actions/change_settings/sfx_off":
			await _apply_setting_action("sfx_off")

		"actions/change_settings/reduce_motion_on":
			await _apply_setting_action("reduce_motion_on")

		"actions/change_settings/reduce_motion_off":
			await _apply_setting_action("reduce_motion_off")

		"actions/change_settings/theme_dark":
			await _apply_setting_action("theme_dark")

		"actions/change_settings/theme_light":
			await _apply_setting_action("theme_light")

		"actions/change_settings/wake_word_detection_on":
			await _apply_setting_action("wake_word_detection_on")
		
		"actions/change_settings/music_on":
			await _apply_setting_action("music_on")

		"actions/change_settings/music_off":
			await _apply_setting_action("music_off")
		
		"actions/change_settings/wake_word_detection_off":
			pass

		"actions/navigate/go_home":
			await _run_navigation_action("go_home")

		"actions/navigate/enter_menu":
			await _run_navigation_action("enter_menu")

		"actions/navigate/exit_menu":
			await _run_navigation_action("exit_menu")

		"actions/navigate/enter_settings":
			await _run_navigation_action("enter_settings")

		"actions/navigate/exit_settings":
			await _run_navigation_action("exit_settings")

		"actions/navigate/enter_planet_cards":
			await _run_navigation_action("enter_planet_cards")

		"actions/navigate/exit_planet_cards":
			await _run_navigation_action("exit_planet_cards")
		
		"actions/navigate/enter_galaxy":
			await _run_navigation_action("enter_galaxy")

		"actions/navigate/exit_galaxy":
			await _run_navigation_action("exit_galaxy")
		
		"actions/navigate/enter_achievements":
			await _run_navigation_action("enter_achievements", params)

		"actions/navigate/exit_achievements":
			await _run_navigation_action("exit_achievements", params)

		"actions/navigate/enter_multiplayer":
			await _run_navigation_action("enter_multiplayer", params)

		"actions/navigate/exit_multiplayer":
			await _run_navigation_action("exit_multiplayer", params)

		"actions/create/planet":
			await _run_create_planet_action(spoken_text)

		"actions/create/solar_system":
			_call_app_controller("create_solar_system", spoken_text)

		"actions/create/galaxy":
			_call_app_controller("create_galaxy", spoken_text)

		"just_talk/joke":
			pass
		
		"actions/simulation/add_body":
			await _apply_simulation_add_body(spoken_text)

		"actions/simulation/remove_body":
			_apply_simulation_remove_body(spoken_text)

		"actions/galaxy/center_anchor":
			await _apply_galaxy_utility_action("center_anchor")

		"actions/galaxy/reset_orbits":
			await _apply_galaxy_utility_action("reset_orbits")

		"actions/galaxy/clear_trails":
			await _apply_galaxy_utility_action("clear_trails")
		
		"actions/galaxy/reset_camera":
			await _apply_galaxy_utility_action("reset_camera")

		"actions/galaxy/set_simulation_parameter":
			_apply_galaxy_parameter_action(params)

		"actions/galaxy/toggle_setting":
			_apply_galaxy_toggle_action(params)


func execute_after_response(folder: String, _spoken_text: String = "", _params: Dictionary = {}) -> void:
	folder = folder.strip_edges()

	match folder:
		"actions/change_settings/wake_word_detection_off":
			await _apply_setting_action("wake_word_detection_off")

			if assistant != null:
				assistant.stop()


func _ai_achievement_kind_for_folder(folder: String) -> String:
	folder = folder.strip_edges()

	if folder.begins_with(ACTION_CHANGE_SETTINGS):
		return "settings"

	if folder.begins_with(ACTION_NAVIGATE):
		return "navigation"

	if folder.begins_with(ACTION_CREATE):
		return "creation"

	# Galaxy Remote should only mean Galaxy Console Settings:
	# percentages + behaviour toggles. Not the Commands tab.
	if folder == "actions/galaxy/set_simulation_parameter":
		return "galaxy"

	if folder == "actions/galaxy/toggle_setting":
		return "galaxy"

	if folder.begins_with(ACTION_GALAXY):
		return "action"

	if folder.begins_with(ACTION_SIMULATION):
		return "action"

	if folder.begins_with(JUST_TALK):
		return "chat"

	return ""


func _track_ai_assistant_event(event_type: String, payload: Dictionary = {}) -> void:
	if assistant != null and assistant.has_method("register_ai_assistant_achievement_event"):
		assistant.call("register_ai_assistant_achievement_event", event_type, payload)
		return

	for path in ["/root/UnilearnAchievements", "/root/UnilearnAchievementTracker", "/root/AchievementTracker"]:
		var tracker := get_node_or_null(path)
		if tracker != null and tracker.has_method("register_ai_assistant_event"):
			tracker.call("register_ai_assistant_event", event_type, payload)
			return


func should_resume_after(folder: String) -> bool:
	return folder.strip_edges() != "actions/change_settings/wake_word_detection_off"


func _run_navigation_action(action_id: String, params: Dictionary = {}) -> void:
	await _show_navigation_input_blocker()

	if AI_ACTION_START_PAUSE > 0.0:
		await get_tree().create_timer(AI_ACTION_START_PAUSE).timeout

	await _apply_navigation_action(action_id, params)

	if AI_ACTION_END_PAUSE > 0.0:
		await get_tree().create_timer(AI_ACTION_END_PAUSE).timeout

	if INPUT_BLOCKER_EXTRA_HOLD_TIME > 0.0:
		await get_tree().create_timer(INPUT_BLOCKER_EXTRA_HOLD_TIME).timeout

	await _hide_navigation_input_blocker()


func _run_create_planet_action(spoken_text: String) -> void:
	await _show_navigation_input_blocker()

	if AI_ACTION_START_PAUSE > 0.0:
		await get_tree().create_timer(AI_ACTION_START_PAUSE).timeout

	var prompt := _extract_planet_creation_prompt(spoken_text)
	var existing_ids := _snapshot_planet_card_ids()
	await _apply_create_planet_action(prompt)
	var created_card = await _wait_for_new_planet_card(existing_ids, prompt, 28.0)

	if created_card != null:
		_track_ai_successful_planet_creation(spoken_text, prompt, created_card)

	if AI_CREATE_AFTER_PLUS_PAUSE > 0.0:
		await get_tree().create_timer(AI_CREATE_AFTER_PLUS_PAUSE).timeout

	if INPUT_BLOCKER_EXTRA_HOLD_TIME > 0.0:
		await get_tree().create_timer(INPUT_BLOCKER_EXTRA_HOLD_TIME).timeout

	await _hide_navigation_input_blocker()


func _show_navigation_input_blocker() -> void:
	_ensure_navigation_input_blocker()

	if not is_instance_valid(_input_blocker_layer) or not is_instance_valid(_input_blocker):
		return

	_input_blocker_layer.visible = true
	_input_blocker_layer.layer = INPUT_BLOCKER_LAYER
	_input_blocker.mouse_filter = Control.MOUSE_FILTER_STOP


func _hide_navigation_input_blocker() -> void:
	if is_instance_valid(_input_blocker_layer):
		_input_blocker_layer.queue_free()

	_input_blocker_layer = null
	_input_blocker = null


func _planet_card_runtime_id(card) -> String:
	if card == null:
		return ""

	var id := _card_string(card, "instance_id").strip_edges()

	if id.is_empty():
		id = _card_string(card, "name").strip_edges()

	return id


func _snapshot_planet_card_ids() -> Dictionary:
	var ids := {}

	for card in _get_cached_planet_cards():
		var id := _planet_card_runtime_id(card)
		if not id.is_empty():
			ids[id] = true

	return ids


func _wait_for_new_planet_card(existing_ids: Dictionary, query: String, timeout: float = 28.0):
	var elapsed := 0.0
	var step := 0.20
	var normalized_query := _normalize_search_score_text(query)

	while elapsed < timeout:
		var new_cards := []

		for card in _get_cached_planet_cards():
			var id := _planet_card_runtime_id(card)

			if id.is_empty() or existing_ids.has(id):
				continue

			new_cards.append(card)

			# Prefer a generated card that clearly belongs to this request.
			if normalized_query.is_empty() or _planet_card_relevance_score(card, normalized_query) > 0.0:
				return card

		# In normal use there is only one active creation; if exactly one new card
		# appeared, it is the successful result even if the backend renamed it.
		if new_cards.size() == 1:
			return new_cards[0]

		await get_tree().create_timer(step).timeout
		elapsed += step

	return null


func _track_ai_successful_planet_creation(spoken_text: String, prompt: String, card) -> void:
	var payload := {
		"folder": "actions/create/planet",
		"kind": "creation",
		"text": spoken_text,
		"prompt": prompt,
		"card_name": _card_string(card, "name"),
		"card_id": _planet_card_runtime_id(card),
		"params": {"prompt": prompt}
	}

	_track_ai_assistant_event("action", payload)
	_track_ai_assistant_event("creation", payload)
	_track_ai_assistant_event("successful_command", payload)


func _ensure_navigation_input_blocker() -> void:
	if is_instance_valid(_input_blocker_layer) and is_instance_valid(_input_blocker):
		return

	_input_blocker_layer = CanvasLayer.new()
	_input_blocker_layer.name = "ApolloNavigationInputBlockerLayer"
	_input_blocker_layer.layer = INPUT_BLOCKER_LAYER
	_input_blocker_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	_input_blocker_layer.visible = true

	_input_blocker = Control.new()
	_input_blocker.name = "ApolloNavigationInputBlocker"
	_input_blocker.set_anchors_preset(Control.PRESET_FULL_RECT)
	_input_blocker.offset_left = 0
	_input_blocker.offset_top = 0
	_input_blocker.offset_right = 0
	_input_blocker.offset_bottom = 0
	_input_blocker.mouse_filter = Control.MOUSE_FILTER_STOP
	_input_blocker.focus_mode = Control.FOCUS_ALL
	_input_blocker.process_mode = Node.PROCESS_MODE_ALWAYS
	_input_blocker.modulate.a = 0.0

	_input_blocker.gui_input.connect(func(event: InputEvent) -> void:
		if event is InputEventMouseButton:
			get_viewport().set_input_as_handled()
		elif event is InputEventMouseMotion:
			get_viewport().set_input_as_handled()
		elif event is InputEventScreenTouch:
			get_viewport().set_input_as_handled()
		elif event is InputEventScreenDrag:
			get_viewport().set_input_as_handled()
	)

	_input_blocker_layer.add_child(_input_blocker)

	var root := get_tree().root if get_tree() != null else null

	if root != null:
		root.add_child(_input_blocker_layer)


func _extract_planet_creation_prompt(spoken_text: String) -> String:
	var text := spoken_text.strip_edges()

	if text.is_empty():
		return "planet"

	var lower := text.to_lower()

	var prefixes := [
		"create me ",
		"generate me ",
		"make me ",
		"build me ",
		"add me ",
		"spawn me ",

		"create for me ",
		"generate for me ",
		"make for me ",
		"build for me ",

		"create ",
		"generate ",
		"make ",
		"build ",
		"add ",
		"spawn "
	]

	for prefix in prefixes:
		if lower.begins_with(prefix):
			text = text.substr(prefix.length()).strip_edges()
			break

	text = _strip_polite_creation_prefix(text)

	if text.is_empty():
		return "planet"

	return text


func _strip_polite_creation_prefix(value: String) -> String:
	var text := value.strip_edges()
	var lower := text.to_lower()

	var removable_prefixes := [
		"please ",
		"a new ",
		"an new ",
		"new ",
		"custom ",
		"some ",
		"one ",
		"the object ",
		"an object ",
		"a object "
	]

	for prefix in removable_prefixes:
		if lower.begins_with(prefix):
			text = text.substr(prefix.length()).strip_edges()
			lower = text.to_lower()
			break

	return text


func _apply_create_planet_action(prompt: String) -> void:
	var menu := _get_bottom_menu()

	if menu != null and menu.has_method("simulate_ai_create_planet"):
		await menu.simulate_ai_create_planet(prompt)
		return

	_call_app_controller("create_planet", prompt)


func _apply_setting_action(action_id: String) -> void:
	if _is_setting_action_already_applied(action_id):
		return

	var popup := _get_open_settings_popup()

	if popup != null and popup.has_method("simulate_ai_setting_tap"):
		var handled: bool = await popup.simulate_ai_setting_tap(action_id)

		if handled:
			return

	_apply_setting_direct(action_id)


func _is_setting_action_already_applied(action_id: String) -> bool:
	if settings == null:
		settings = get_node_or_null("/root/UnilearnUserSettings")

	if settings == null:
		return false

	match action_id:
		"sfx_on":
			return "sfx_enabled" in settings and bool(settings.sfx_enabled)

		"sfx_off":
			return "sfx_enabled" in settings and not bool(settings.sfx_enabled)

		"reduce_motion_on":
			return "reduce_motion_enabled" in settings and bool(settings.reduce_motion_enabled)

		"reduce_motion_off":
			return "reduce_motion_enabled" in settings and not bool(settings.reduce_motion_enabled)

		"theme_dark":
			return "theme_dark_mode" in settings and bool(settings.theme_dark_mode)

		"theme_light":
			return "theme_dark_mode" in settings and not bool(settings.theme_dark_mode)

		"wake_word_detection_on":
			return "apollo_enabled" in settings and bool(settings.apollo_enabled)

		"wake_word_detection_off":
			return "apollo_enabled" in settings and not bool(settings.apollo_enabled)
		
		"music_on":
			return "music_enabled" in settings and bool(settings.music_enabled)

		"music_off":
			return "music_enabled" in settings and not bool(settings.music_enabled)

		_:
			return false


func _apply_setting_direct(action_id: String) -> void:
	match action_id:
		"sfx_on":
			_set_sfx_enabled(true)

		"sfx_off":
			_set_sfx_enabled(false)

		"reduce_motion_on":
			_set_reduce_motion_enabled(true)

		"reduce_motion_off":
			_set_reduce_motion_enabled(false)

		"theme_dark":
			_set_theme_dark_mode(true)

		"theme_light":
			_set_theme_dark_mode(false)

		"wake_word_detection_on":
			_set_apollo_enabled(true)

		"wake_word_detection_off":
			_set_apollo_enabled(false)
		
		"music_on":
			_set_music_enabled(true)

		"music_off":
			_set_music_enabled(false)


func _get_open_settings_popup() -> Node:
	var tree := get_tree()

	if tree == null or tree.root == null:
		return null

	return _find_settings_popup_recursive(tree.root)


func _find_settings_popup_recursive(node: Node) -> Node:
	if node == null:
		return null

	if node.has_method("simulate_ai_setting_tap"):
		return node

	if node.name.to_lower().contains("settingspopup"):
		return node

	for child in node.get_children():
		var found := _find_settings_popup_recursive(child)

		if found != null:
			return found

	return null


func _set_sfx_enabled(value: bool) -> void:
	if settings == null:
		settings = get_node_or_null("/root/UnilearnUserSettings")

	if settings == null:
		return

	if "sfx_enabled" in settings and bool(settings.sfx_enabled) == value:
		return

	if settings.has_method("set_sfx_enabled"):
		settings.set_sfx_enabled(value)

	_update_sfx_node_live(value)


func _set_reduce_motion_enabled(value: bool) -> void:
	if settings == null:
		settings = get_node_or_null("/root/UnilearnUserSettings")

	if settings == null:
		return

	if "reduce_motion_enabled" in settings and bool(settings.reduce_motion_enabled) == value:
		return

	if settings.has_method("set_reduce_motion_enabled"):
		settings.set_reduce_motion_enabled(value)


func _set_theme_dark_mode(value: bool) -> void:
	if settings == null:
		settings = get_node_or_null("/root/UnilearnUserSettings")

	if settings == null:
		return

	if "theme_dark_mode" in settings and bool(settings.theme_dark_mode) == value:
		return

	if settings.has_method("set_theme_dark_mode"):
		settings.set_theme_dark_mode(value)


func _set_apollo_enabled(value: bool) -> void:
	if settings == null:
		settings = get_node_or_null("/root/UnilearnUserSettings")

	if settings == null:
		return

	if "apollo_enabled" in settings and bool(settings.apollo_enabled) == value:
		return

	if settings.has_method("set_wake_word_detection_enabled"):
		settings.set_wake_word_detection_enabled(value)
		return

	if settings.has_method("set_apollo_enabled"):
		settings.set_apollo_enabled(value)


func _set_music_enabled(value: bool) -> void:
	if settings == null:
		settings = get_node_or_null("/root/UnilearnUserSettings")

	if settings == null:
		return

	if "music_enabled" in settings and bool(settings.music_enabled) == value:
		return

	if settings.has_method("set_music_enabled"):
		settings.set_music_enabled(value)

	_update_music_node_live(value)


func _update_music_node_live(value: bool) -> void:
	var music := get_node_or_null("/root/UnilearnMusic")

	if music == null:
		return

	if music.has_method("set_enabled"):
		music.set_enabled(value)
	elif "enabled" in music:
		music.enabled = value
	elif "music_enabled" in music:
		music.music_enabled = value


func _update_sfx_node_live(value: bool) -> void:
	var sfx := get_node_or_null("/root/UnilearnSFX")

	if sfx == null:
		return

	if sfx.has_method("set_enabled"):
		sfx.set_enabled(value)
	elif "enabled" in sfx:
		sfx.enabled = value


func _apply_navigation_action(action_id: String, params: Dictionary = {}) -> void:
	var menu := _get_bottom_menu()
	var category := str(params.get("category", "")).strip_edges()

	if menu != null:
		match action_id:
			"go_home":
				if menu.has_method("simulate_ai_go_home"):
					await menu.simulate_ai_go_home()
					return

			"enter_menu":
				if menu.has_method("simulate_ai_enter_menu"):
					await menu.simulate_ai_enter_menu()
					return

			"exit_menu":
				if menu.has_method("simulate_ai_exit_menu"):
					await menu.simulate_ai_exit_menu()
					return

			"enter_settings":
				if menu.has_method("simulate_ai_enter_settings"):
					await menu.simulate_ai_enter_settings()
					return

			"exit_settings":
				if menu.has_method("simulate_ai_exit_settings"):
					await menu.simulate_ai_exit_settings()
					return

			"enter_planet_cards":
				if menu.has_method("simulate_ai_enter_planet_cards"):
					await menu.simulate_ai_enter_planet_cards()
					return

			"exit_planet_cards":
				if menu.has_method("simulate_ai_exit_planet_cards"):
					await menu.simulate_ai_exit_planet_cards()
					return

			"enter_galaxy":
				if menu.has_method("simulate_ai_enter_galaxy"):
					await menu.simulate_ai_enter_galaxy()
					return

			"exit_galaxy":
				if menu.has_method("simulate_ai_exit_galaxy"):
					await menu.simulate_ai_exit_galaxy()
					return

			"enter_achievements":
				if menu.has_method("simulate_ai_enter_achievements"):
					await menu.simulate_ai_enter_achievements(category)
					return

			"exit_achievements":
				if menu.has_method("simulate_ai_exit_achievements"):
					await menu.simulate_ai_exit_achievements()
					return

			"enter_multiplayer":
				if menu.has_method("simulate_ai_enter_multiplayer"):
					await menu.simulate_ai_enter_multiplayer()
					return

			"exit_multiplayer":
				if menu.has_method("simulate_ai_exit_multiplayer"):
					await menu.simulate_ai_exit_multiplayer()
					return

	match action_id:
		"go_home":
			_call_app_controller("go_home")

		"enter_menu":
			_call_app_controller("enter_menu")

		"exit_menu":
			_call_app_controller("exit_menu")

		"enter_settings":
			_call_app_controller("enter_settings")

		"exit_settings":
			_call_app_controller("exit_settings")

		"enter_planet_cards":
			_call_app_controller("enter_planet_cards")

		"exit_planet_cards":
			_call_app_controller("exit_planet_cards")

		"enter_galaxy":
			_call_app_controller("enter_galaxy")

		"exit_galaxy":
			_call_app_controller("exit_galaxy")

		"enter_achievements":
			_call_app_controller("enter_achievements", category)

		"exit_achievements":
			_call_app_controller("exit_achievements")

		"enter_multiplayer":
			_call_app_controller("enter_multiplayer")

		"exit_multiplayer":
			_call_app_controller("exit_multiplayer")


func _is_navigation_action_already_applied(action_id: String, params: Dictionary = {}) -> bool:
	var menu := _get_bottom_menu()

	if menu == null or not menu.has_method("get_app_location"):
		return false

	var location := str(menu.call("get_app_location")).strip_edges()
	var category := str(params.get("category", "")).strip_edges()

	match action_id:
		"go_home":
			return location == "home"

		"enter_menu":
			return location == "menu"

		"exit_menu":
			return location != "menu"

		"enter_settings":
			return location == "settings"

		"exit_settings":
			return location != "settings"

		"enter_planet_cards":
			return location == "planet_cards"

		"exit_planet_cards":
			return location != "planet_cards"

		"enter_galaxy":
			return location == "galaxy"

		"exit_galaxy":
			return location != "galaxy"

		"enter_achievements":
			if location != "achievements":
				return false

			if category.is_empty():
				return true

			return _is_open_achievement_category(category)

		"exit_achievements":
			return location != "achievements"

		"enter_multiplayer":
			return location == "multiplayer"

		"exit_multiplayer":
			return location != "multiplayer"

		_:
			return false


func _is_open_achievement_category(category: String) -> bool:
	var popup := _get_open_achievements_popup()

	if popup == null:
		return false

	var selected := ""

	if popup.has_method("get_ai_selected_category"):
		selected = str(popup.call("get_ai_selected_category")).strip_edges()
	elif _object_has_property(popup, "_selected_category"):
		selected = str(popup.get("_selected_category")).strip_edges()

	return not selected.is_empty() and selected == category.strip_edges()


func _get_open_achievements_popup() -> Node:
	var tree := get_tree()

	if tree == null or tree.root == null:
		return null

	return _find_open_achievements_popup_recursive(tree.root)


func _find_open_achievements_popup_recursive(node: Node) -> Node:
	if node == null:
		return null

	if node.has_method("simulate_ai_open_category"):
		return node

	if node.name.to_lower().contains("achievementspopup"):
		return node

	for child in node.get_children():
		var found := _find_open_achievements_popup_recursive(child)

		if found != null:
			return found

	return null


func _get_bottom_menu() -> Node:
	var tree := get_tree()

	if tree == null or tree.root == null:
		return null

	return _find_bottom_menu_recursive(tree.root)


func _find_bottom_menu_recursive(node: Node) -> Node:
	if node == null:
		return null

	if node.has_method("simulate_ai_enter_menu") and node.has_method("simulate_ai_exit_menu"):
		return node

	if node.name.to_lower().contains("bottommenu"):
		return node

	for child in node.get_children():
		var found := _find_bottom_menu_recursive(child)

		if found != null:
			return found

	return null


func _call_app_controller(method_name: String, arg: Variant = null) -> void:
	var controller := _get_app_controller()

	if controller == null:
		return

	if not controller.has_method(method_name):
		return

	if arg == null:
		controller.call(method_name)
	else:
		controller.call(method_name, arg)


func _get_app_controller() -> Node:
	var paths := [
		"/root/UnilearnAppController",
		"/root/AppCommandBus",
		"/root/ApolloAppController",
		"/root/UnilearnNavigation"
	]

	for path in paths:
		var node := get_node_or_null(path)

		if node != null:
			return node

	return null




func _apply_simulation_add_body(spoken_text: String) -> void:
	var query := _extract_planet_query_from_command(spoken_text)

	if query.is_empty():
		query = _extract_planet_creation_prompt(spoken_text)

	if query.is_empty():
		push_warning("Apollo could not understand what planet to add.")
		return

	var card: Variant = _find_planet_card_from_query(query, true)

	if card != null:
		await _close_any_open_popup_for_scene_add()
		_add_card_to_simulation(card)
		return

	await _generate_planet_then_add_to_simulation(query)

func _apply_simulation_remove_body(spoken_text: String) -> void:
	var query := _extract_planet_query_from_command(spoken_text)

	if query.is_empty():
		push_warning("Apollo could not understand what planet to remove.")
		return

	var card: Variant = _find_planet_card_from_query(query, true)

	if card == null:
		push_warning("Apollo could not find a planet card to remove for: " + query)
		return

	var universe := _get_universe_playground()

	if universe == null:
		push_warning("Apollo could not find UniversePlayground.")
		return

	if not _is_card_currently_in_scene(card):
		push_warning("Apollo found the card, but it is not in the scene: " + _card_display_name(card))
		return

	await _close_any_open_popup_for_scene_add()

	if universe.has_method("remove_planet_card"):
		universe.call("remove_planet_card", card)

func _apply_galaxy_utility_action(action_id: String) -> void:
	var universe := _get_universe_playground()

	if universe == null:
		push_warning("Apollo could not find UniversePlayground for galaxy action: " + action_id)
		return

	match action_id:
		"center_anchor":
			if universe.has_method("center_anchor_body"):
				universe.call("center_anchor_body")

		"reset_orbits":
			if universe.has_method("reset_orbits"):
				universe.call("reset_orbits")

		"clear_trails":
			if universe.has_method("clear_trails"):
				universe.call("clear_trails")

		"reset_camera":
			# The spoken command should work from anywhere. If the Galaxy popup is open,
			# close it first, then run the same camera reset the app uses manually.
			await _close_open_galaxy_popup_for_ai()

			if universe.has_method("reset_camera"):
				universe.call("reset_camera")
			else:
				_reset_camera_fallback()

func _apply_galaxy_parameter_action(params: Dictionary) -> void:
	var parameter := str(params.get("parameter", "")).strip_edges()
	var percent := _safe_percent(params.get("percent", 0))

	if parameter.is_empty():
		return

	var property_name := _map_ai_parameter_to_config_property(parameter)

	if property_name.is_empty():
		push_warning("Apollo unknown simulation parameter: " + parameter)
		return

	var value = _config_value_from_percent(property_name, percent)
	_apply_galaxy_config_value(property_name, value)

func _apply_galaxy_toggle_action(params: Dictionary) -> void:
	var property := str(params.get("property", "")).strip_edges()
	var enabled := _safe_bool(params.get("value", false))
	var property_name := _map_ai_toggle_to_config_property(property)

	if property_name.is_empty():
		push_warning("Apollo unknown galaxy toggle: " + property)
		return

	_apply_galaxy_config_value(property_name, enabled)

func _is_galaxy_parameter_already_applied(params: Dictionary) -> bool:
	var parameter := str(params.get("parameter", "")).strip_edges()
	var percent := _safe_percent(params.get("percent", 0))

	if parameter.is_empty():
		return false

	var property_name := _map_ai_parameter_to_config_property(parameter)

	if property_name.is_empty():
		return false

	var target_value = _config_value_from_percent(property_name, percent)
	var current_value = _get_current_galaxy_config_value(property_name)

	if current_value == null:
		return false

	return _values_close(current_value, target_value)


func _is_galaxy_toggle_already_applied(params: Dictionary) -> bool:
	var property := str(params.get("property", "")).strip_edges()
	var target_value := _safe_bool(params.get("value", false))
	var property_name := _map_ai_toggle_to_config_property(property)

	if property_name.is_empty():
		return false

	var current_value = _get_current_galaxy_config_value(property_name)

	if current_value == null:
		return false

	return bool(current_value) == target_value


func _get_current_galaxy_config_value(property_name: String):
	var popup := _get_open_galaxy_popup()
	var popup_config = _get_config_from_node(popup)

	if popup_config != null and _object_has_property(popup_config, property_name):
		return popup_config.get(property_name)

	var universe := _get_universe_playground()
	var universe_config = _get_config_from_node(universe)

	if universe_config != null and _object_has_property(universe_config, property_name):
		return universe_config.get(property_name)

	var galaxy_state := get_node_or_null("/root/GalaxyState")

	if galaxy_state == null:
		galaxy_state = get_node_or_null("/root/UnilearnGalaxyState")

	if galaxy_state != null and _object_has_property(galaxy_state, property_name):
		return galaxy_state.get(property_name)

	return null


func _get_config_from_node(node: Node):
	if node == null:
		return null

	if _object_has_property(node, "config"):
		return node.get("config")

	if _object_has_property(node, "_config"):
		return node.get("_config")

	if node.has_method("get_simulation_config"):
		return node.call("get_simulation_config")

	return null


func _object_has_property(object: Object, property_name: String) -> bool:
	if object == null:
		return false

	for item in object.get_property_list():
		if str(item.get("name", "")) == property_name:
			return true

	return false


func _values_close(a: Variant, b: Variant) -> bool:
	if a is bool or b is bool:
		return bool(a) == bool(b)

	if a is float or a is int or b is float or b is int:
		return abs(float(a) - float(b)) <= 0.004

	return str(a) == str(b)


func _safe_percent(value: Variant) -> float:
	var percent := 0.0

	if value is float or value is int:
		percent = float(value)
	else:
		percent = float(str(value).to_float())

	return clamp(percent, 0.0, 100.0)

func _safe_bool(value: Variant) -> bool:
	if value is bool:
		return value

	var clean := str(value).strip_edges().to_lower()

	return clean == "true" or clean == "1" or clean == "on" or clean == "yes" or clean == "enabled"

func _map_ai_parameter_to_config_property(parameter: String) -> String:
	match parameter:
		"simulation_speed":
			return "simulation_speed"

		"orbit_speed_multiplier":
			return "orbit_speed_multiplier"

		"center_anchor_strength":
			return "center_anchor_strength"

		"orbit_lock_strength":
			return "orbit_lock_strength"

		"stable_orbit_radius_multiplier":
			return "stable_orbit_radius_multiplier"

		"drag_throw_strength":
			return "drag_throw_strength"

		_:
			return ""

func _map_ai_toggle_to_config_property(property: String) -> String:
	match property:
		"center_largest_bodies":
			return "center_largest_body"

		"stable_orbits":
			return "stable_orbit_mode"

		"trajectories":
			return "trails_enabled"

		_:
			return ""

func _config_value_from_percent(property_name: String, percent: float) -> Variant:
	var ratio = clamp(percent / 100.0, 0.0, 1.0)

	match property_name:
		"simulation_speed":
			return lerp(0.05, 32.0, ratio)

		"orbit_speed_multiplier":
			return lerp(0.05, 32.0, ratio)

		"center_anchor_strength":
			return ratio

		"orbit_lock_strength":
			return ratio

		"stable_orbit_radius_multiplier":
			return lerp(0.1, 1.0, ratio)

		"drag_throw_strength":
			return ratio

		_:
			return ratio

func _apply_galaxy_config_value(property_name: String, value: Variant) -> void:
	var popup := _get_open_galaxy_popup()

	if popup != null and popup.has_method("apply_ai_config_value_live"):
		popup.call("apply_ai_config_value_live", property_name, value)
		return

	var universe := _get_universe_playground()

	if universe != null and universe.has_method("apply_config_value"):
		universe.call("apply_config_value", property_name, value)
		return

	var galaxy_state := get_node_or_null("/root/GalaxyState")

	if galaxy_state == null:
		galaxy_state = get_node_or_null("/root/UnilearnGalaxyState")

	if galaxy_state != null:
		if galaxy_state.has_method("set_config_value"):
			galaxy_state.call("set_config_value", property_name, value)
			return

		if galaxy_state.has_method("apply_config_value"):
			galaxy_state.call("apply_config_value", property_name, value)
			return

	push_warning("Apollo could not apply galaxy config value: " + property_name)

func _add_card_to_simulation(card) -> void:
	if card == null:
		return

	var universe := _get_universe_playground()

	if universe == null:
		push_warning("Apollo could not find UniversePlayground.")
		return

	if universe.has_method("is_planet_card_added"):
		if bool(universe.call("is_planet_card_added", card)):
			return

	var spawn_position := Vector2.ZERO
	var viewport := get_viewport()

	if viewport != null and universe.has_method("screen_to_space"):
		spawn_position = universe.call("screen_to_space", viewport.get_visible_rect().size * 0.5)

	if universe.has_method("add_planet_card"):
		universe.call("add_planet_card", card, spawn_position)

func _generate_planet_then_add_to_simulation(query: String) -> void:
	var existing_ids := _snapshot_planet_card_ids()
	var menu := _get_bottom_menu()

	if menu != null and menu.has_method("simulate_ai_create_planet"):
		await menu.simulate_ai_create_planet(query, true)
		await _close_any_open_popup_for_scene_add()
		await _wait_for_generated_card_and_add(query, existing_ids)
		return

	_call_app_controller("create_planet", query)
	await _close_any_open_popup_for_scene_add()
	await _wait_for_generated_card_and_add(query, existing_ids)

func _wait_for_generated_card_and_add(query: String, existing_ids: Dictionary = {}) -> void:
	var timeout := 28.0
	var elapsed := 0.0
	var step := 0.20

	while elapsed < timeout:
		var new_cards := []

		for card in _get_cached_planet_cards():
			var id := _planet_card_runtime_id(card)

			if id.is_empty():
				continue

			if not existing_ids.is_empty() and existing_ids.has(id):
				continue

			if existing_ids.is_empty():
				if _planet_card_relevance_score(card, query) > 0.0:
					await _close_any_open_popup_for_scene_add()
					_add_card_to_simulation(card)
					return
			else:
				new_cards.append(card)

		if new_cards.size() == 1:
			await _close_any_open_popup_for_scene_add()
			_add_card_to_simulation(new_cards[0])
			return

		for card in new_cards:
			if _planet_card_relevance_score(card, query) > 0.0:
				await _close_any_open_popup_for_scene_add()
				_add_card_to_simulation(card)
				return

		await get_tree().create_timer(step).timeout
		elapsed += step

	push_warning("Apollo generated/search requested a planet, but no new card appeared for: " + query)


func _find_planet_card_from_query(query: String, require_confident_match: bool = false):
	query = query.strip_edges().to_lower()

	if query.is_empty():
		return null

	var cards := _get_cached_planet_cards()
	var best_card = null
	var best_score := 0.0

	for card in cards:
		if card == null:
			continue

		var score := _planet_card_relevance_score(card, query)

		if score > best_score:
			best_score = score
			best_card = card

	if best_card == null:
		return null

	if require_confident_match and not _planet_card_score_is_confident(query, best_score):
		return null

	return best_card


func _get_cached_planet_cards() -> Array:
	var cache := get_node_or_null("/root/PlanetCardsCache")

	if cache == null:
		return []

	if cache.has_method("get_all_cards"):
		var all_cards = cache.call("get_all_cards")

		if all_cards is Array:
			return all_cards

	if cache.has_method("get_cards"):
		var cards = cache.call("get_cards")

		if cards is Array:
			return cards

	if "cards" in cache:
		var direct_cards = cache.get("cards")

		if direct_cards is Array:
			return direct_cards

	return []


func _planet_card_score_is_confident(query: String, score: float) -> bool:
	# Matching is Ctrl+F style on name/description only. A positive score means
	# the normalized command text exists as a substring in one of those fields.
	return not _normalize_search_score_text(query).is_empty() and score > 0.0


func _planet_card_relevance_score(card, query: String) -> float:
	var q := _normalize_search_score_text(query)

	if q.is_empty():
		return 0.0

	var name_score := _substring_search_field_score(_card_string(card, "name"), q, 150.0, 110.0, 82.0)
	var description_score := _substring_search_field_score(_card_string(card, "description"), q, 28.0, 20.0, 12.0)

	return max(name_score, description_score)


func _substring_search_field_score(value: String, query: String, exact_score: float, prefix_score: float, contains_score: float) -> float:
	var text := _normalize_search_score_text(value)

	if text.is_empty() or query.is_empty():
		return 0.0

	if text == query:
		return exact_score

	if text.begins_with(query):
		return prefix_score

	if text.contains(query):
		return contains_score

	return 0.0


func _card_string(card, property_name: String) -> String:
	if card == null:
		return ""

	for item in card.get_property_list():
		if str(item.get("name", "")) == property_name:
			return str(card.get(property_name))

	return ""


func _card_array_dictionary_text(card, property_name: String) -> String:
	if card == null:
		return ""

	var has_property := false
	for item in card.get_property_list():
		if str(item.get("name", "")) == property_name:
			has_property = true
			break

	if not has_property:
		return ""

	var value = card.get(property_name)
	var parts: Array[String] = []

	if value is Array:
		for item in value:
			if item is Dictionary:
				for key in item.keys():
					parts.append(str(item.get(key, "")))
			else:
				parts.append(str(item))

	return " ".join(parts)


func _planet_card_full_haystack(card) -> String:
	var fields := [
		"name", "instance_id", "subtitle", "description", "object_category",
		"archetype_id", "planet_preset", "parent_object", "system_role",
		"visual_signature", "composition", "atmosphere", "surface_geology",
		"magnetic_field", "ring_system", "habitability_note", "formation_note",
		"discovery_note", "notable_extreme", "exploration_status", "diameter_km",
		"mass", "orbital_period", "rotation_period", "average_temperature",
		"gravity", "moons", "distance_from_sun", "fun_fact", "quiz_text",
		"compare_text", "missions_text"
	]
	var parts: Array[String] = []

	for field in fields:
		parts.append(_card_string(card, field))

	parts.append(_card_array_dictionary_text(card, "key_features"))
	parts.append(_card_array_dictionary_text(card, "overview_points"))
	parts.append(_card_array_dictionary_text(card, "data_cards"))
	parts.append(_card_array_dictionary_text(card, "learning_prompts"))
	parts.append(_card_array_dictionary_text(card, "attribute_badges"))

	return _normalize_search_score_text(" ".join(parts))


func _search_score_tokens(query: String) -> Array[String]:
	var tokens: Array[String] = []
	for part in query.split(" ", false):
		var token := str(part).strip_edges()
		if token.length() >= 2 and not tokens.has(token):
			tokens.append(token)
	return tokens


func _normalize_search_score_text(value: String) -> String:
	var result := value.strip_edges().to_lower()
	result = result.replace("’s", " ")
	result = result.replace("'s", " ")
	result = result.replace("’", " ")
	result = result.replace("'", " ")
	result = result.replace("_", " ")
	result = result.replace("-", " ")
	result = result.replace(".", " ")
	result = result.replace(",", " ")
	result = result.replace(":", " ")
	result = result.replace(";", " ")
	result = result.replace("(", " ")
	result = result.replace(")", " ")
	result = result.replace("/", " ")
	result = result.replace("\\", " ")

	while result.contains("  "):
		result = result.replace("  ", " ")

	return result.strip_edges()


func _contains_exact_phrase(text: String, query: String) -> bool:
	return (" " + text + " ").contains(" " + query + " ")


func _contains_exact_token(text: String, token: String) -> bool:
	return (" " + text + " ").contains(" " + token + " ")


func _card_display_name(card) -> String:
	var name := _card_string(card, "name").strip_edges()
	return name if not name.is_empty() else "That planet"


func _is_card_currently_in_scene(card) -> bool:
	var universe := _get_universe_playground()

	if universe == null or card == null:
		return false

	if universe.has_method("is_planet_card_added"):
		return bool(universe.call("is_planet_card_added", card))

	var id := _planet_card_runtime_id(card)
	if not id.is_empty() and universe.has_method("is_planet_card_id_added"):
		return bool(universe.call("is_planet_card_id_added", id))

	return false


func _extract_planet_query_from_command(spoken_text: String) -> String:
	var text := spoken_text.strip_edges()

	if text.is_empty():
		return ""

	var lower := text.to_lower()

	var starters := [
		"apollo",
		"please",
		"can you",
		"could you",
		"would you",
		"add",
		"put",
		"place",
		"spawn",
		"insert",
		"bring",
		"show",
		"remove",
		"delete",
		"take out",
		"hide",
		"despawn",
		"clear"
	]

	for starter in starters:
		if lower.begins_with(starter + " "):
			text = text.substr(starter.length()).strip_edges()
			lower = text.to_lower()

	var end_phrases := [
		" to the screen",
		" to screen",
		" to the scene",
		" to scene",
		" to the simulation",
		" to simulation",
		" to the universe",
		" to universe",
		" into the screen",
		" into screen",
		" into the scene",
		" into scene",
		" into the simulation",
		" into simulation",
		" on the screen",
		" on screen",
		" from the screen",
		" from screen",
		" from the scene",
		" from scene",
		" from the simulation",
		" from simulation",
		" from the universe",
		" from universe"
	]

	for phrase in end_phrases:
		var index := lower.find(phrase)

		if index >= 0:
			text = text.substr(0, index).strip_edges()
			lower = text.to_lower()
			break

	if lower.begins_with("a "):
		text = text.substr(2).strip_edges()
	elif lower.begins_with("an "):
		text = text.substr(3).strip_edges()
	elif lower.begins_with("the "):
		text = text.substr(4).strip_edges()

	return text.strip_edges()

func _close_any_open_popup_for_scene_add() -> void:
	var menu := _get_bottom_menu()

	if menu != null and menu.has_method("_navigate_home_for_ai"):
		await menu.call("_navigate_home_for_ai")
		return

	await _close_open_planet_cards_popup_for_ai()
	await _close_open_galaxy_popup_for_ai()
	await get_tree().process_frame


func _close_open_planet_cards_popup_for_ai() -> void:
	var popup := _get_open_planet_cards_popup()

	if popup == null:
		return

	if popup.has_method("close_popup"):
		popup.call("close_popup")
	else:
		popup.queue_free()

	if is_instance_valid(popup):
		if popup.has_signal("closed"):
			await popup.closed
		else:
			await popup.tree_exited

	await get_tree().process_frame


func _get_open_planet_cards_popup() -> Node:
	var tree := get_tree()

	if tree == null or tree.root == null:
		return null

	return _find_open_planet_cards_popup_recursive(tree.root)


func _find_open_planet_cards_popup_recursive(node: Node) -> Node:
	if node == null:
		return null

	if node.name.to_lower().contains("planetcardspopup") or node.name.to_lower().contains("planet_cards_popup"):
		return node

	if node.has_signal("planet_add_requested") and node.has_signal("planet_remove_requested"):
		return node

	for child in node.get_children():
		var found := _find_open_planet_cards_popup_recursive(child)

		if found != null:
			return found

	return null


func _get_universe_playground() -> Node:
	var tree := get_tree()

	if tree == null:
		return null

	if tree.current_scene != null:
		var found := _find_universe_playground_recursive(tree.current_scene)

		if found != null:
			return found

	if tree.root != null:
		return _find_universe_playground_recursive(tree.root)

	return null

func _find_universe_playground_recursive(node: Node) -> Node:
	if node == null:
		return null

	if node.name == "UniversePlayground":
		return node

	if node.has_method("add_planet_card") and node.has_method("remove_planet_card"):
		return node

	for child in node.get_children():
		var found := _find_universe_playground_recursive(child)

		if found != null:
			return found

	return null


func _close_open_galaxy_popup_for_ai() -> void:
	var popup := _get_open_galaxy_popup()

	if popup == null:
		return

	if popup.has_method("close_popup"):
		popup.call("close_popup")

	if popup.has_signal("closed"):
		await popup.closed
	else:
		await get_tree().process_frame

func _get_open_galaxy_popup() -> Node:
	var tree := get_tree()

	if tree == null or tree.root == null:
		return null

	return _find_open_galaxy_popup_recursive(tree.root)

func _find_open_galaxy_popup_recursive(node: Node) -> Node:
	if node == null:
		return null

	if node.has_signal("reset_camera_requested"):
		return node

	if node.name.to_lower().contains("galaxypopup"):
		return node

	for child in node.get_children():
		var found := _find_open_galaxy_popup_recursive(child)

		if found != null:
			return found

	return null

func _reset_camera_fallback() -> void:
	var background := _get_space_background_node()

	if background == null:
		return

	if background.has_method("reset_navigation_view_smooth"):
		background.call("reset_navigation_view_smooth", 1.05)
		return

	if background.has_method("reset_navigation_view"):
		background.call("reset_navigation_view")
		return

	if background.has_method("reset_camera"):
		background.call("reset_camera")
		return

	if background.has_method("reset_view"):
		background.call("reset_view")
		return

	if background.get("space_position") is Vector2:
		background.set("space_position", Vector2.ZERO)
		background.set("target_space_position", Vector2.ZERO)

	if background.get("space_rotation") != null:
		background.set("space_rotation", 0.0)
		background.set("target_space_rotation", 0.0)


func _get_space_background_node() -> Node:
	var direct := get_node_or_null("/root/SpaceBackground")
	if direct != null:
		return direct

	var tree := get_tree()
	if tree == null or tree.root == null:
		return null

	return _find_space_background_recursive(tree.root)


func _find_space_background_recursive(node: Node) -> Node:
	if node == null:
		return null

	if node.name == "SpaceBackground" or node.has_method("reset_navigation_view_smooth"):
		return node

	for child in node.get_children():
		var found := _find_space_background_recursive(child)
		if found != null:
			return found

	return null
